<table class="table table-responsive" id="slides-table">
    <thead>
        <tr>
            <th>Img</th>
        <th>Des</th>
        <th>Title</th>
        <th>Title2</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $slide->img; ?></td>
            <td><?php echo $slide->des; ?></td>
            <td><?php echo $slide->title; ?></td>
            <td><?php echo $slide->title2; ?></td>
            <td>
                <?php echo Form::open(['route' => ['slides.destroy', $slide->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('slides.show', [$slide->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('slides.edit', [$slide->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>