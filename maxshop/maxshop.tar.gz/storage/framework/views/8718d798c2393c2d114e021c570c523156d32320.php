<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $slide->id; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $slide->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $slide->updated_at; ?></p>
</div>

<!-- Img Field -->
<div class="form-group">
    <?php echo Form::label('img', 'Img:'); ?>

    <p><?php echo $slide->img; ?></p>
</div>

<!-- Des Field -->
<div class="form-group">
    <?php echo Form::label('des', 'Des:'); ?>

    <p><?php echo $slide->des; ?></p>
</div>

<!-- Title Field -->
<div class="form-group">
    <?php echo Form::label('title', 'Title:'); ?>

    <p><?php echo $slide->title; ?></p>
</div>

<!-- Title2 Field -->
<div class="form-group">
    <?php echo Form::label('title2', 'Title2:'); ?>

    <p><?php echo $slide->title2; ?></p>
</div>

