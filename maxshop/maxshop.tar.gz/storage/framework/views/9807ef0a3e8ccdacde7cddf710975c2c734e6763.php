<table class="table table-responsive" id="orderItems-table">
    <thead>
        <tr>
            <th>Order Id</th>
        <th>Product Id</th>
        <th>Money</th>
        <th>Quantity</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $orderItem->order_id; ?></td>
            <td><?php echo $orderItem->product_id; ?></td>
            <td><?php echo $orderItem->money; ?></td>
            <td><?php echo $orderItem->quantity; ?></td>
            <td>
                <?php echo Form::open(['route' => ['orderItems.destroy', $orderItem->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('orderItems.show', [$orderItem->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('orderItems.edit', [$orderItem->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>