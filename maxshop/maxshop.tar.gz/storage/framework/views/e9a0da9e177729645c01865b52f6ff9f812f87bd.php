<table class="table table-responsive" id="orders-table">
    <thead>
        <tr>
            <th>User Id</th>
        <th>Status</th>
        <th>Countrie Id</th>
        <th>Address</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Office Home Others</th>
        <th>Address1</th>
        <th>Address2</th>
        <th>City</th>
        <th>Email</th>
        <th>Phone</th>
        <th>State</th>
        <th>Zipcode</th>
        <th>Totalmoney</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $order->user_id; ?></td>
            <td><?php echo $order->status; ?></td>
            <td><?php echo $order->countrie_id; ?></td>
            <td><?php echo $order->address; ?></td>
            <td><?php echo $order->first_name; ?></td>
            <td><?php echo $order->last_name; ?></td>
            <td><?php echo $order->office_home_others; ?></td>
            <td><?php echo $order->address1; ?></td>
            <td><?php echo $order->address2; ?></td>
            <td><?php echo $order->city; ?></td>
            <td><?php echo $order->email; ?></td>
            <td><?php echo $order->phone; ?></td>
            <td><?php echo $order->state; ?></td>
            <td><?php echo $order->zipcode; ?></td>
            <td><?php echo $order->totalmoney; ?></td>
            <td>
                <?php echo Form::open(['route' => ['orders.destroy', $order->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('orders.show', [$order->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('orders.edit', [$order->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>