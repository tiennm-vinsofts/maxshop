<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $product->id; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $product->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $product->updated_at; ?></p>
</div>

<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo $product->name; ?></p>
</div>

<!-- Category Id Field -->
<div class="form-group">
    <?php echo Form::label('category_id', 'Category Id:'); ?>

    <p><?php echo $product->category_id; ?></p>
</div>

<!-- Priceold Field -->
<div class="form-group">
    <?php echo Form::label('priceold', 'Priceold:'); ?>

    <p><?php echo $product->priceold; ?></p>
</div>

<!-- Pricenew Field -->
<div class="form-group">
    <?php echo Form::label('pricenew', 'Pricenew:'); ?>

    <p><?php echo $product->pricenew; ?></p>
</div>

<!-- Ranks Field -->
<div class="form-group">
    <?php echo Form::label('ranks', 'Ranks:'); ?>

    <p><?php echo $product->ranks; ?></p>
</div>

<!-- Status Field -->
<div class="form-group">
    <?php echo Form::label('status', 'Status:'); ?>

    <p><?php echo $product->status; ?></p>
</div>

<!-- Img Field -->
<div class="form-group">
    <?php echo Form::label('img', 'Img:'); ?>

    <?php echo e(Html::image($product->img,'anh',['class'=>'img-responsive'])); ?>

</div>

<!-- Des Field -->
<div class="form-group">
    <?php echo Form::label('des', 'Des:'); ?>

    <p><?php echo $product->des; ?></p>
</div>

<!-- Des Field -->
<div class="form-group">
    <?php echo Form::label('des', 'Des:'); ?>

    <p><?php echo $product->des; ?></p>
</div>

