<li class="<?php echo e(Request::is('categories*') ? 'active' : ''); ?>">
    <a href="<?php echo route('categories.index'); ?>"><i class="fa fa-edit"></i><span>Categories</span></a>
</li>

<li class="<?php echo e(Request::is('products*') ? 'active' : ''); ?>">
    <a href="<?php echo route('products.index'); ?>"><i class="fa fa-edit"></i><span>Products</span></a>
</li>

<li class="<?php echo e(Request::is('countries*') ? 'active' : ''); ?>">
    <a href="<?php echo route('countries.index'); ?>"><i class="fa fa-edit"></i><span>Countries</span></a>
</li>

<li class="<?php echo e(Request::is('orders*') ? 'active' : ''); ?>">
    <a href="<?php echo route('orders.index'); ?>"><i class="fa fa-edit"></i><span>Orders</span></a>
</li>

<li class="<?php echo e(Request::is('orderItems*') ? 'active' : ''); ?>">
    <a href="<?php echo route('orderItems.index'); ?>"><i class="fa fa-edit"></i><span>Order Items</span></a>
</li>

<li class="<?php echo e(Request::is('slides*') ? 'active' : ''); ?>">
    <a href="<?php echo route('slides.index'); ?>"><i class="fa fa-edit"></i><span>Slides</span></a>
</li>

