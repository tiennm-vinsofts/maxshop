<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Priceold Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('priceold', 'Priceold:'); ?>

    <?php echo Form::number('priceold', null, ['class' => 'form-control']); ?>

</div>

<!-- Pricenew Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('pricenew', 'Pricenew:'); ?>

    <?php echo Form::number('pricenew', null, ['class' => 'form-control']); ?>

</div>

<!-- Ranks Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ranks', 'Ranks:'); ?>

    <?php echo Form::number('ranks', null, ['class' => 'form-control']); ?>

</div>

<!-- Status Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('status', 'Status:'); ?>

    <?php echo Form::number('status', null, ['class' => 'form-control']); ?>

</div>

<!-- Img Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('img', 'Img:'); ?>

    <?php echo Form::file('img'); ?>

    <?php if(isset( $product->img)): ?>
    <?php echo e(Html::image($product->img,'anh',['class'=>'img-responsive'])); ?>

        <?php endif; ?>
</div>
<div class="clearfix"></div>

<!-- Category_id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('category_id', 'Category id:'); ?>

    <?php echo Form::select('category_id', $category_list,null,['class' => 'form-control']); ?>

</div>
<div class="clearfix"></div>

<!-- Des Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('des', 'Des:'); ?>

    <?php echo Form::text('des', null, ['class' => 'form-control']); ?>

</div>

<!-- Des2 Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('des2', 'Des2:'); ?>

    <?php echo Form::textarea('des2', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('products.index'); ?>" class="btn btn-default">Cancel</a>
</div>
