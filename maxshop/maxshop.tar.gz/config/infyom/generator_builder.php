<?php

return [

    'views' => [

//        'builder' => 'generator-builder::builder',
        'builder' => 'infyom.generator-builder.builder',

//        'field-template' => 'generator-builder::field-template'
        'field-template' => 'infyom.generator-builder.field-template'
    ]
];