const config = {
    urlsever: "http://192.168.1.23/maxshop/maxshop/public/",
    urlapi: "http://192.168.1.23/maxshop/maxshop/public/index.php/api/"
};
export default config;