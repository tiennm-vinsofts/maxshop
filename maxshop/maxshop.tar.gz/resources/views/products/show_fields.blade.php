<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $product->id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $product->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $product->updated_at !!}</p>
</div>

<!-- Name Field -->
<div class="form-group">
    {!! Form::label('name', 'Name:') !!}
    <p>{!! $product->name !!}</p>
</div>

<!-- Category Id Field -->
<div class="form-group">
    {!! Form::label('category_id', 'Category Id:') !!}
    <p>{!! $product->category_id !!}</p>
</div>

<!-- Priceold Field -->
<div class="form-group">
    {!! Form::label('priceold', 'Priceold:') !!}
    <p>{!! $product->priceold !!}</p>
</div>

<!-- Pricenew Field -->
<div class="form-group">
    {!! Form::label('pricenew', 'Pricenew:') !!}
    <p>{!! $product->pricenew !!}</p>
</div>

<!-- Ranks Field -->
<div class="form-group">
    {!! Form::label('ranks', 'Ranks:') !!}
    <p>{!! $product->ranks !!}</p>
</div>

<!-- Status Field -->
<div class="form-group">
    {!! Form::label('status', 'Status:') !!}
    <p>{!! $product->status !!}</p>
</div>

<!-- Img Field -->
<div class="form-group">
    {!! Form::label('img', 'Img:') !!}
    {{ Html::image($product->img,'anh',['class'=>'img-responsive']) }}
</div>

<!-- Des Field -->
<div class="form-group">
    {!! Form::label('des', 'Des:') !!}
    <p>{!! $product->des !!}</p>
</div>

<!-- Des Field -->
<div class="form-group">
    {!! Form::label('des', 'Des:') !!}
    <p>{!! $product->des !!}</p>
</div>

